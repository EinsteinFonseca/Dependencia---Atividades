﻿using System;
class atividade
{
    static void Main(string[] args)
    {
        /* Console.Write("Digite o valor de A: ");
         int A = Convert.ToInt32(Console.ReadLine());

         Console.Write("Digite o valor de B: ");
         int B = Convert.ToInt32(Console.ReadLine());

         Console.Write("Digite o valor de C: ");
         int C = Convert.ToInt32(Console.ReadLine());

         if (A + B <= C)
         {
             Console.WriteLine("A soma de A+B é menor que C");
         }
         else if (A + B >= C)
         {
             Console.WriteLine("A Soma de A+B é maior que C");
         }
        */

        //======================================================================================

        /*
        Console.Write("Digite um número:");
        int num1 = Convert.ToInt32(Console.ReadLine());

        if (num1 % 2 == 0)
        {
            Console.WriteLine("Esse numero é par");
            num1 += 5;
        }

        else if (num1 % 2 == 1)
        {
            Console.WriteLine("Esse numero é impar");
            num1 += 8;
        }

        Console.WriteLine();
        Console.WriteLine($"O resultado da operação é {num1} ");
        */

        //=======================================================================================

        Console.Write("Insira sua altura:");
        double altura = Convert.ToDouble(Console.ReadLine());

        Console.Write("Insira seu sexo (M para homens e F para mulheres):");
        string sexo = Console.ReadLine();

        if (sexo == "M")
        {
            double calculoHomens = (72.7 * altura) - 58;
            Console.WriteLine($"Para Homens: {calculoHomens} ");
        }

        else if (sexo == "F") 
        {
            double calculoMulheres = (62.1 * altura) - 44.7;
            Console.WriteLine($"Para mulheres: {calculoMulheres}");
        }


        //==============================================================================================

        Console.Write("Insira sua Nota1: ");
        int nota1 = Convert.ToInt32(Console.ReadLine);

        Console.Write("Insira sua Nota2: ");
        int nota2 = Convert.ToInt32(Console.ReadLine);

        Console.Write("Insira sua Nota3: ");
        int nota3 = Convert.ToInt32(Console.ReadLine);

        Console.WriteLine();

        int media = nota1 + nota2 + nota3;
        Console.WriteLine($"A sua média é: {media}");

        if (media >= 7 )
        {
            Console.WriteLine("Aprovado");
        }
        else if (media <= 7 && >= 4)
        {

        }

        Console.ReadKey();
    }

}